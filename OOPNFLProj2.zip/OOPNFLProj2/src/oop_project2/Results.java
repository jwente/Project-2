package oop_project2;

public interface Results {
	
	String viewTeams();
	String searchConference(String Conf);
	String searchDivision(String Conf, String Location);
	String viewTeamRoster(String teamName);
}
